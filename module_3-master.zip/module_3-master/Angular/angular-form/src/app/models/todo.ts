export class Todo{
    userId: string;
    id: number;
    title:string;
    completed: boolean;
}