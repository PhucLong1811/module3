export class Project {
    id: number;
    title: string;
    content: Text;
    status: boolean;
    finishdate?: Date
}