export class nameCard{
	cardName: string;
	email: string;
	phone: number;
}