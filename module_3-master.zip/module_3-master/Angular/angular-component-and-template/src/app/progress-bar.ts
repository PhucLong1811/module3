export class progress_bar{
	backgroundColor1:string;
	progressColor:string;
	width: number;
}