function greeter(person) {
    return "Hello, " + person;
}
var user = "Jane User";
console.log(greeter(user));
