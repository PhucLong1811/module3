function greeter(person) {
    return "Hello, " + person;
}
let user = "Jane User";
console.log(greeter(user));
