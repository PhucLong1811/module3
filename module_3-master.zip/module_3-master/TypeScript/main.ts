function greeter(person: string): string {
return "Hello, " + person;
}
let user: string = "Jane User";
console.log(greeter(user));